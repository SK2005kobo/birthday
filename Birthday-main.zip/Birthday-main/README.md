# Birthday

A Happy Birthday animation design in CSS3, HTML5, JavaScript.

## Installation

### Prerequisites
- Web browser
- Text editor

### Setup
1. Clone the repository
   ```bash
   git clone https://github.com/randillasith/Birthday.git
   
#### [See it Live](https://randillasith.github.io/Birthday/)

